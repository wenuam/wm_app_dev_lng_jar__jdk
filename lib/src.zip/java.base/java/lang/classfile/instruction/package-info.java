/*
 * Copyright (c) 2023, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/**
 * <h2>Provides interfaces describing code instructions for the {@link java.lang.classfile} library.</h2>
 *
 * The {@code java.lang.classfile.attribute} package contains interfaces describing code instructions.
 *
 * @since 22
 */
@PreviewFeature(feature = PreviewFeature.Feature.CLASSFILE_API)
package java.lang.classfile.instruction;

import jdk.internal.javac.PreviewFeature;
